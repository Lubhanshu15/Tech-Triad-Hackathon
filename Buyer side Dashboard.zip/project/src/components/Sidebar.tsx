import React from 'react';
import { 
  LayoutDashboard, 
  ShoppingCart, 
  Package, 
  BarChart3, 
  MessageSquare, 
  Settings,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import type { MenuItem } from '../types/dashboard';

const menuItems: MenuItem[] = [
  { name: 'Dashboard Overview', icon: 'LayoutDashboard', path: '/' },
  { name: 'Orders', icon: 'ShoppingCart', path: '/orders', badge: 5 },
  { name: 'Inventory', icon: 'Package', path: '/inventory' },
  { name: 'Analytics', icon: 'BarChart3', path: '/analytics' },
  { name: 'Messages', icon: 'MessageSquare', path: '/messages', badge: 3 },
  { name: 'Settings', icon: 'Settings', path: '/settings' },
];

const iconComponents = {
  LayoutDashboard,
  ShoppingCart,
  Package,
  BarChart3,
  MessageSquare,
  Settings,
};

export default function Sidebar() {
  const [collapsed, setCollapsed] = React.useState(false);

  return (
    <div className={`bg-gray-900 text-white transition-all duration-300 ${
      collapsed ? 'w-20' : 'w-64'
    } min-h-screen`}>
      <div className="p-4 flex justify-between items-center">
        <h1 className={`font-bold ${collapsed ? 'hidden' : 'block'}`}>
          Vendor Portal
        </h1>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 hover:bg-gray-800 rounded-lg"
        >
          {collapsed ? (
            <ChevronRight size={20} />
          ) : (
            <ChevronLeft size={20} />
          )}
        </button>
      </div>

      <nav className="mt-8">
        {menuItems.map((item) => {
          const Icon = iconComponents[item.icon as keyof typeof iconComponents];
          return (
            <a
              key={item.name}
              href={item.path}
              className="flex items-center px-4 py-3 text-gray-300 hover:bg-gray-800 hover:text-white transition-colors relative"
            >
              <Icon size={20} />
              <span className={`ml-4 ${collapsed ? 'hidden' : 'block'}`}>
                {item.name}
              </span>
              {item.badge && (
                <span className="absolute right-4 bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  {item.badge}
                </span>
              )}
            </a>
          );
        })}
      </nav>
    </div>
  );
}