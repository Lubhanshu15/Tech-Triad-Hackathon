export interface Order {
  id: string;
  productName: string;
  status: 'pending' | 'processing' | 'shipped' | 'delivered';
  deliveryDate: string;
  sellerName: string;
  amount: number;
}

export interface WishlistItem {
  id: string;
  name: string;
  price: number;
  image: string;
  inStock: boolean;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'order' | 'promo' | 'system';
  read: boolean;
  timestamp: string;
}

export interface User {
  name: string;
  email: string;
  avatar: string;
}