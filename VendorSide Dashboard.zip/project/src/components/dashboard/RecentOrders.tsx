import React from 'react';
import { Package } from 'lucide-react';
import type { Order } from '../../types';

const orders: Order[] = [
  {
    id: 'ORD-001',
    productName: 'Wireless Headphones',
    status: 'processing',
    deliveryDate: '2024-03-20',
    sellerName: 'Tech Store',
    amount: 129.99,
  },
  {
    id: 'ORD-002',
    productName: 'Smart Watch',
    status: 'shipped',
    deliveryDate: '2024-03-18',
    sellerName: 'Gadget World',
    amount: 199.99,
  },
  {
    id: 'ORD-003',
    productName: 'Laptop Stand',
    status: 'delivered',
    deliveryDate: '2024-03-15',
    sellerName: 'Office Supplies Co',
    amount: 49.99,
  },
];

const statusColors = {
  pending: 'bg-yellow-100 text-yellow-800',
  processing: 'bg-blue-100 text-blue-800',
  shipped: 'bg-purple-100 text-purple-800',
  delivered: 'bg-green-100 text-green-800',
};

export default function RecentOrders() {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Package className="h-5 w-5 text-gray-600" />
            <h2 className="text-lg font-semibold text-gray-900">Recent Orders</h2>
          </div>
          <button className="text-sm text-blue-600 hover:text-blue-700">View All</button>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="text-left bg-gray-50">
              <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Order ID</th>
              <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
              <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
              <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Delivery Date</th>
              <th className="px-6 py-3 text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {orders.map((order) => (
              <tr key={order.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 text-sm text-gray-900">{order.id}</td>
                <td className="px-6 py-4">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{order.productName}</p>
                    <p className="text-sm text-gray-500">{order.sellerName}</p>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[order.status]}`}>
                    {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-gray-500">{order.deliveryDate}</td>
                <td className="px-6 py-4 text-sm text-gray-900">${order.amount.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}