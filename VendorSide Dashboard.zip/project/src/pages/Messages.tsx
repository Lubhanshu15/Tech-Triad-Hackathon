import React from 'react';
import { MessageSquare, Send } from 'lucide-react';

const messages = [
  {
    id: 1,
    sender: 'Tech Store',
    message: 'Your order #ORD-001 has been shipped. Tracking number: TRK123456',
    timestamp: '2024-03-15 14:30',
    isUser: false,
  },
  {
    id: 2,
    sender: 'You',
    message: 'Thank you! When can I expect the delivery?',
    timestamp: '2024-03-15 14:35',
    isUser: true,
  },
  {
    id: 3,
    sender: 'Tech Store',
    message: 'The estimated delivery date is March 20th. You can track your package using the tracking number provided.',
    timestamp: '2024-03-15 14:40',
    isUser: false,
  },
];

export default function Messages() {
  return (
    <div className="h-[calc(100vh-7rem)] flex flex-col space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Messages</h1>
        <p className="mt-1 text-sm text-gray-500">Chat with sellers and support</p>
      </div>

      <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col">
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center space-x-2">
            <MessageSquare className="h-5 w-5 text-gray-600" />
            <span className="font-medium text-gray-900">Tech Store</span>
          </div>
        </div>

        <div className="flex-1 p-4 space-y-4 overflow-y-auto">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.isUser ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[70%] rounded-lg p-3 ${
                  message.isUser
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}
              >
                <p className="text-sm">{message.message}</p>
                <p className={`text-xs mt-1 ${message.isUser ? 'text-blue-100' : 'text-gray-500'}`}>
                  {message.timestamp}
                </p>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-gray-100">
          <div className="flex space-x-2">
            <input
              type="text"
              placeholder="Type your message..."
              className="flex-1 rounded-lg border border-gray-200 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500">
              <Send className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}