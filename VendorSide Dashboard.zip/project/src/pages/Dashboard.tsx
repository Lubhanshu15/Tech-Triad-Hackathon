import React from 'react';
import { ShoppingBag, CreditCard, Heart, TrendingUp } from 'lucide-react';
import StatCard from '../components/dashboard/StatCard';
import RecentOrders from '../components/dashboard/RecentOrders';

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Welcome back, John!</h1>
        <p className="mt-1 text-sm text-gray-500">Here's what's happening with your store today.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Orders"
          value="156"
          icon={ShoppingBag}
          trend={{ value: 12, isPositive: true }}
        />
        <StatCard
          title="Total Spent"
          value="$4,385.00"
          icon={CreditCard}
          trend={{ value: 8, isPositive: true }}
        />
        <StatCard
          title="Wishlist Items"
          value="24"
          icon={Heart}
        />
        <StatCard
          title="Active RFQs"
          value="8"
          icon={TrendingUp}
          trend={{ value: 2, isPositive: false }}
        />
      </div>

      <RecentOrders />
    </div>
  );
}