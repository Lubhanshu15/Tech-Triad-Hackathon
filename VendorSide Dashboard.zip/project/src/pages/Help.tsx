import React from 'react';
import { HelpCircle, ChevronDown, Search } from 'lucide-react';

const faqs = [
  {
    question: 'How do I track my order?',
    answer: 'You can track your order by going to the Orders page and clicking on the specific order. You\'ll find real-time tracking information and delivery updates there.',
  },
  {
    question: 'What payment methods do you accept?',
    answer: 'We accept all major credit cards (Visa, MasterCard, American Express), PayPal, and bank transfers. Payment information can be managed in your account settings.',
  },
  {
    question: 'How do I return an item?',
    answer: 'To return an item, go to your Orders page, select the order containing the item you want to return, and click the "Return Item" button. Follow the instructions to complete the return process.',
  },
  {
    question: 'How do I contact customer support?',
    answer: 'You can reach our customer support team through the Messages page, by email at support@example.com, or by phone at 1-800-123-4567. We\'re available 24/7 to assist you.',
  },
];

export default function Help() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Help Center</h1>
        <p className="mt-1 text-sm text-gray-500">Find answers to common questions</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search for help..."
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        <div className="divide-y divide-gray-100">
          {faqs.map((faq, index) => (
            <details key={index} className="group">
              <summary className="flex items-center justify-between p-6 cursor-pointer">
                <div className="flex items-center space-x-3">
                  <HelpCircle className="h-5 w-5 text-gray-400" />
                  <h3 className="text-sm font-medium text-gray-900">{faq.question}</h3>
                </div>
                <ChevronDown className="h-5 w-5 text-gray-400 transform transition-transform group-open:rotate-180" />
              </summary>
              <div className="px-6 pb-6">
                <p className="text-sm text-gray-500">{faq.answer}</p>
              </div>
            </details>
          ))}
        </div>
      </div>

      <div className="bg-blue-50 rounded-xl p-6">
        <h2 className="text-lg font-semibold text-gray-900">Still need help?</h2>
        <p className="mt-2 text-sm text-gray-600">
          Our customer support team is available 24/7 to assist you with any questions or concerns.
        </p>
        <div className="mt-4 space-x-4">
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            Contact Support
          </button>
          <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
            Submit Ticket
          </button>
        </div>
      </div>
    </div>
  );
}