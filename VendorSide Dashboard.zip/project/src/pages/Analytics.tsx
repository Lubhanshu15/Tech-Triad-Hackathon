import React from 'react';
import { BarChart2, TrendingUp, DollarSign, ShoppingBag } from 'lucide-react';
import StatCard from '../components/dashboard/StatCard';

export default function Analytics() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
        <p className="mt-1 text-sm text-gray-500">View your purchasing trends and statistics</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Monthly Spend"
          value="$2,456.00"
          icon={DollarSign}
          trend={{ value: 15, isPositive: true }}
        />
        <StatCard
          title="Orders This Month"
          value="45"
          icon={ShoppingBag}
          trend={{ value: 5, isPositive: true }}
        />
        <StatCard
          title="Average Order Value"
          value="$54.58"
          icon={TrendingUp}
          trend={{ value: 3, isPositive: false }}
        />
        <StatCard
          title="Active Vendors"
          value="12"
          icon={BarChart2}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Monthly Spending Trend</h2>
          <div className="h-64 flex items-center justify-center">
            <p className="text-gray-500">Chart will be implemented here</p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Category Distribution</h2>
          <div className="h-64 flex items-center justify-center">
            <p className="text-gray-500">Chart will be implemented here</p>
          </div>
        </div>
      </div>
    </div>
  );
}