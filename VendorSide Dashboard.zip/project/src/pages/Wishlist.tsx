import React from 'react';
import { Heart, ShoppingCart, Trash2 } from 'lucide-react';
import type { WishlistItem } from '../types';

const wishlistItems: WishlistItem[] = [
  {
    id: 'WISH-001',
    name: 'Premium Wireless Keyboard',
    price: 149.99,
    image: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=300&h=300',
    inStock: true,
  },
  {
    id: 'WISH-002',
    name: 'Ultra-wide Monitor',
    price: 699.99,
    image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=300&h=300',
    inStock: true,
  },
  {
    id: 'WISH-003',
    name: 'Ergonomic Office Chair',
    price: 299.99,
    image: 'https://images.unsplash.com/photo-1505797149-35ebcb05a2fc?auto=format&fit=crop&w=300&h=300',
    inStock: false,
  },
];

export default function Wishlist() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">My Wishlist</h1>
        <p className="mt-1 text-sm text-gray-500">Items you've saved for later</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {wishlistItems.map((item) => (
          <div key={item.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <img
              src={item.image}
              alt={item.name}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900">{item.name}</h3>
              <p className="mt-2 text-2xl font-bold text-gray-900">${item.price.toFixed(2)}</p>
              <p className="mt-1 text-sm text-gray-500">
                {item.inStock ? (
                  <span className="text-green-600">In Stock</span>
                ) : (
                  <span className="text-red-600">Out of Stock</span>
                )}
              </p>
              <div className="mt-4 flex gap-2">
                <button
                  disabled={!item.inStock}
                  className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-sm font-medium ${
                    item.inStock
                      ? 'bg-blue-600 text-white hover:bg-blue-700'
                      : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  }`}
                >
                  <ShoppingCart className="h-4 w-4" />
                  Add to Cart
                </button>
                <button className="p-2 text-gray-400 hover:text-red-600 rounded-lg hover:bg-gray-50">
                  <Trash2 className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}