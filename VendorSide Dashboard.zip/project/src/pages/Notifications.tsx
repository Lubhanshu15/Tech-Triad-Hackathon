import React from 'react';
import { Bell, Package, Tag, Info } from 'lucide-react';
import type { Notification } from '../types';

const notifications: Notification[] = [
  {
    id: 'NOTIF-001',
    title: 'Order Shipped',
    message: 'Your order #ORD-001 has been shipped and will arrive by March 20th.',
    type: 'order',
    read: false,
    timestamp: '2024-03-15 14:30',
  },
  {
    id: 'NOTIF-002',
    title: 'Special Offer',
    message: 'Get 20% off on all electronics this weekend!',
    type: 'promo',
    read: true,
    timestamp: '2024-03-14 09:15',
  },
  {
    id: 'NOTIF-003',
    title: 'System Update',
    message: "We've updated our privacy policy. Please review the changes.", // Fixed single quote issue
    type: 'system',
    read: true,
    timestamp: '2024-03-13 16:45',
  },
];

const notificationIcons = {
  order: Package,
  promo: Tag,
  system: Info,
};

export default function Notifications() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
        <p className="mt-1 text-sm text-gray-500">Stay updated with your orders and offers</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Bell className="h-5 w-5 text-gray-600" />
              <h2 className="text-lg font-semibold text-gray-900">All Notifications</h2>
            </div>
            <button className="text-sm text-blue-600 hover:text-blue-700">Mark all as read</button>
          </div>
        </div>

        <div className="divide-y divide-gray-100">
          {notifications.map((notification) => {
            const Icon = notificationIcons[notification.type];
            return (
              <div
                key={notification.id}
                className={`p-6 flex items-start space-x-4 ${
                  notification.read ? 'bg-white' : 'bg-blue-50'
                }`}
              >
                <div
                  className={`p-2 rounded-full ${
                    notification.type === 'order'
                      ? 'bg-purple-100 text-purple-600'
                      : notification.type === 'promo'
                      ? 'bg-green-100 text-green-600'
                      : 'bg-orange-100 text-orange-600'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="text-sm font-medium text-gray-900">{notification.title}</h3>
                      <p className="mt-1 text-sm text-gray-500">{notification.message}</p>
                    </div>
                    <span className="text-xs text-gray-400">{notification.timestamp}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
